/**
 * @file xc.h
 * The XINU standard C Library, libxc.
 *
 * $Id: xc.h 170 2007-07-11 18:45:46Z mschul $
 */
/* Embedded XINU, Copyright (C) 2007.  All rights reserved. */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
